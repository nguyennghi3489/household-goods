<?php 

if( ! function_exists( 'road_get_slider_setting' ) ) {
	function road_get_slider_setting() {
		return array(
			array(
				'type'        => 'dropdown',
				'holder'      => 'div',
				'heading'     => esc_html__( 'Style', 'debaco' ),
				'param_name'  => 'style',
				'value'       => array(
					__( 'Grid view', 'debaco' )                    => 'product-grid',
					__( 'List view 1', 'debaco' )                  => 'product-list',
					__( 'List view 2', 'debaco' )                  => 'product-list-2',
					__( 'Grid view with countdown', 'debaco' )     => 'product-grid-countdown',
				),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Enable slider', 'debaco' ),
				'description' => __( 'If slider is enabled, the "column" ins General group is the number of rows ', 'debaco' ),
				'param_name'  => 'enable_slider',
				'value'       => true,
				'save_always' => true, 
				'group'       => __( 'Slider Options', 'debaco' ),
			),
			array(
				'type'       => 'textfield',
				'holder'     => 'div',
				'heading'    => __( 'Number of columns (screen: over 1500px)', 'debaco' ),
				'param_name' => 'items_1500up',
				'group'      => __( 'Slider Options', 'debaco' ),
				'value'      => esc_html__( '4', 'debaco' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 1200px - 1499px)', 'debaco' ),
				'param_name' => 'items_1200_1499',
				'group'      => __( 'Slider Options', 'debaco' ),
				'value'      => esc_html__( '4', 'debaco' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 992px - 1199px)', 'debaco' ),
				'param_name' => 'items_992_1199',
				'group'      => __( 'Slider Options', 'debaco' ),
				'value'      => esc_html__( '4', 'debaco' ),
			), 
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 768px - 991px)', 'debaco' ),
				'param_name' => 'items_768_991',
				'group'      => __( 'Slider Options', 'debaco' ),
				'value'      => esc_html__( '3', 'debaco' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 640px - 767px)', 'debaco' ),
				'param_name' => 'items_640_767',
				'group'      => __( 'Slider Options', 'debaco' ),
				'value'      => esc_html__( '2', 'debaco' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: 480px - 639px)', 'debaco' ),
				'param_name' => 'items_480_639',
				'group'      => __( 'Slider Options', 'debaco' ),
				'value'      => esc_html__( '2', 'debaco' ),
			),
			array(
				'type'       => 'textfield',
				'heading'    => __( 'Number of columns (screen: under 479px)', 'debaco' ),
				'param_name' => 'items_0_479',
				'group'      => __( 'Slider Options', 'debaco' ),
				'value'      => esc_html__( '1', 'debaco' ),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Navigation', 'debaco' ),
				'param_name'  => 'navigation',
				'save_always' => true,
				'group'       => __( 'Slider Options', 'debaco' ),
				'value'       => array(
					__( 'Yes', 'debaco' ) => true,
					__( 'No', 'debaco' )  => false,
				),
			),
			array(
				'type'        => 'dropdown',
				'heading'     => __( 'Pagination', 'debaco' ),
				'param_name'  => 'pagination',
				'save_always' => true,
				'group'       => __( 'Slider Options', 'debaco' ),
				'value'       => array(
					__( 'No', 'debaco' )  => false,
					__( 'Yes', 'debaco' ) => true,
				),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Item Margin (unit: pixel)', 'debaco' ),
				'param_name'  => 'item_margin',
				'value'       => 30,
				'save_always' => true,
				'group'       => __( 'Slider Options', 'debaco' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Slider speed number (unit: second)', 'debaco' ),
				'param_name'  => 'speed',
				'value'       => '500',
				'save_always' => true,
				'group'       => __( 'Slider Options', 'debaco' ),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Slider loop', 'debaco' ),
				'param_name'  => 'loop',
				'value'       => true,
				'group'       => __( 'Slider Options', 'debaco' ),
			),
			array(
				'type'        => 'checkbox',
				'heading'     => __( 'Slider Auto', 'debaco' ),
				'param_name'  => 'auto',
				'value'       => true,
				'group'       => __( 'Slider Options', 'debaco' ),
			),
			array(
				'type'        => 'dropdown',
				'holder'      => 'div',
				'heading'     => esc_html__( 'Navigation style', 'debaco' ),
				'param_name'  => 'navigation_style',
				'group'       => __( 'Slider Options', 'debaco' ),
				'value'       => array(
					'Navigation center horizontal'	=> 'navigation-style1',
					'Navigation top right'	        => 'navigation-style2',
				),
			),
		);
	}
}